import React, { useState, useEffect } from "react";
import Header from "./Master/Header";
import Sidebar from "./Master/SidebarMenu";

// PrimeReact components
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Button } from "primereact/button";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Sidebar as PrimeSidebar } from "primereact/sidebar";
import { SelectButton } from "primereact/selectbutton";
import { confirmDialog } from "primereact/confirmdialog";

// Bootstrap components
import { Col } from "react-bootstrap";

// Services
import AdhocmanagementService from "../services/compliance/AdhocmanagementService";

const AdhocManagement = () => {
  // Main data states
  const [adhocData, setAdhocData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [visibleLeft, setVisibleLeft] = useState(false);
  const [managerData, setManagerData] = useState([]);
  const [facilityData, setFacilityData] = useState([]);
  const [employeeData, setEmployeeData] = useState([]);
  const [shiftData, setShiftData] = useState([]);
  
  // Remove this line:
  // const [shifts, setShifts] = useState([]);
  //const [selectedShift, setSelectedShift] = useState(null);
  
  // Selected values
  const [selectedManager, setSelectedManager] = useState(null);
  const [selectedFacility, setSelectedFacility] = useState(null);
  const [selectedShift, setSelectedShift] = useState(null);
  const [selectedDate, setSelectedDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  
  // Trip type options
  const options = ["Pick Up", "Drop"];
  const [value, setValue] = useState(options[0]);
  
  // Request type options
  const [requestTypes] = useState([
    { value: "Adhoc", name: "Ad-hoc" },
    { value: "Emergency", name: "Emergency" },
  ]);
  const [selectedRequestType, setSelectedRequestType] = useState(null);

  // Initial data loading
  useEffect(() => {
    fetchAdhocData();
    fetchManagerDropdown();
    fetchFacilityDropdown();
    fetchEmployeeData();
    fetchShiftData();
  }, []);

  // Fetch shift data when dependencies change
  useEffect(() => {
    if (selectedFacility && selectedDate) {
      fetchShiftData();
    }
  }, [selectedFacility, selectedDate, value]);

  // Event handlers
  const handleRequestTypeChange = (e) => {
    setSelectedRequestType(e.value);
    console.log("Selected Request Type:", e.value);
  };

  const openEditSidebar = () => {
    setVisibleLeft(true);
  };

  const handleCancelRequest = (rowData) => {
    // Implement the cancel request logic here
    console.log("Cancelling request:", rowData);
    // Call API to cancel the request
  };

  // Data fetching functions
 const fetchAdhocData = async () => {
    try {
      setLoading(true);
      const endDate = new Date();
      const startDate = new Date();
      startDate.setFullYear(startDate.getFullYear() - 1);

      const formattedStartDate = startDate.toISOString().split("T")[0];
      const formattedEndDate = endDate.toISOString().split("T")[0];

      const empId = sessionStorage.getItem("ID");

      const params = {
        EmpId: parseInt(empId),
        sDate: formattedStartDate,
        eDate: formattedEndDate,
        status: "emp",
      };

      console.log("Sending params Adhoc Data:", params);

      const response = await AdhocmanagementService.SelectEmpAdhocRequest(
        params
      );
      // console.log("API Response:", response);
      const respData = JSON.parse(response);

      console.log("AdhocManagement Details", respData);
      setAdhocData(respData);
    } catch (error) {
      console.log("Error", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchManagerDropdown = async () => {
    try {
      setLoading(true);
      const backupmgrid = sessionStorage.getItem("ID");

      const params = {
        backupmgrid: parseInt(backupmgrid),
      };

      console.log("Fetching manager data with params:", params);
      const response = await AdhocmanagementService.GetBackupMgrId(params);
      
      // Handle the response data
      let managerList = Array.isArray(response) ? response : 
                       (response && typeof response === "object") ? [response] : [];

      console.log("Manager data retrieved:", managerList);
      setManagerData(managerList);

      // Set default manager if available
      if (managerList.length > 0) {
        setSelectedManager(managerList[0]);
      }
    } catch (error) {
      console.error("Error fetching manager data:", error);
      setManagerData([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchFacilityDropdown = async () => {
    try {
      setLoading(true);
      const empId = sessionStorage.getItem("ID");

      const params = {
        EmpId: parseInt(empId),
      };

      console.log("Fetching facility data with params:", params);
      const response = await AdhocmanagementService.SelectFacilityByGroup(params);
      
      // Ensure we have an array of data
      let facilities = Array.isArray(response) ? response : 
                      (response && typeof response === "object") ? [response] : [];

      console.log("Facility data retrieved:", facilities);
      setFacilityData(facilities);

      // Set default facility if available
      if (facilities.length > 0) {
        setSelectedFacility(facilities[0]);
      }
    } catch (error) {
      console.error("Error fetching facility data:", error);
      setFacilityData([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchShiftDropdown = async () => {
    try {
      setLoading(true);
      const empId = sessionStorage.getItem("ID");

      const params = {
        EmpId: parseInt(empId),
      };

      console.log("Fetching facility data with params:", params);
      const response = await AdhocmanagementService.SelectFacilityByGroup(params);
      
      // Ensure we have an array of data
      let facilities = Array.isArray(response) ? response : 
                      (response && typeof response === "object") ? [response] : [];

      console.log("Facility data retrieved:", facilities);
      setFacilityData(facilities);

      // Set default facility if available
      if (facilities.length > 0) {
        setSelectedFacility(facilities[0]);
      }
    } catch (error) {
      console.error("Error fetching facility data:", error);
      setFacilityData([]);
    } finally {
      setLoading(false);
    }
  };

  const fetchShiftData = async () => {
    try {
      setLoading(true);
      
      const params = {
        facilityid: selectedFacility ? parseInt(selectedFacility) : 0,
        sDate: selectedDate,
        type: value,
        processid: 0
      };

      const response = await AdhocmanagementService.getpickshiftAdhoc(params);
      console.log("Shift data response:", response);

      // Process the shift data for dropdown
      let processedShifts = [];
      
      if (Array.isArray(response)) {
        processedShifts = response.map(shift => ({
          ShiftId: shift.shiftTime,
          ShiftName: formatShiftTime(shift.shiftTime),
          ShiftValue: shift.ShiftValue
        }));
      } else if (response && typeof response === 'object') {
        // Handle single object response
        processedShifts = [{
          ShiftId: response.shiftTime ,
          ShiftName: formatShiftTime(response.shiftTime),
          ShiftValue: response.ShiftValue
        }];
      }

      console.log("Processed shifts:", processedShifts);
      setShiftData(processedShifts);
      setSelectedShift(null); // Reset selection when shifts change
    } catch (error) {
      console.error("Error fetching shift data:", error);
      setShiftData([]);
    } finally {
      setLoading(false);
    }
  };
  const formatShiftTime = (time) => {
    // Convert "1900" to "19:00", "2130" to "21:30" etc.
    if (time.length === 4) {
      return `${time.slice(0, 2)}:${time.slice(2)}`;
    }
    return time;
  };
  // UI helper functions
  const isCancelEnabled = (rowData) => {
    return rowData.Enableds === 1 && !rowData.adhocreason.includes("Emergency");
  };

  // UI templates
  const deleteBtn = (rowData) => {
    if (isCancelEnabled(rowData)) {
      return (
        <Button
          label="Cancel"
          className="p-button-danger p-button-sm"
          onClick={() => {
            confirmDialog({
              message: "Are you sure you want to cancel this adhoc request?",
              header: "Confirmation",
              icon: "pi pi-exclamation-triangle",
              accept: () => handleCancelRequest(rowData),
              reject: () => {},
            });
          }}
        />
      );
    } else {
      return <span>Expired</span>;
    }
  };

   // Save button click handler
   const handleSave = () => {
    console.log("Selected Shift:", selectedShift);
    // API call to save can go here
  };

  return (
    <>
      <Header
        pageTitle=""
        showNewButton={true}
        onNewButtonClick={() => setVisibleLeft(true)}
      />
      <Sidebar />
      <div className="middle">
        <div className="row">
          <div className="col-12">
            <h6
              className="pageTitle"
              onClick={() => {
                setVisibleLeft(true);
              }}
            >
              Adhoc's Management
            </h6>
          </div>
        </div>
        
        {/* Stats Cards */}
        <div className="row mt-3">
          <div className="col">
            <div className="cardNew p-4 bg-secondary text-white">
              <h3>37</h3>
              <span className="subtitle_sm text-white">Total Adhocs</span>
            </div>
          </div>
          <div className="col">
            <div className="cardNew p-4">
              <h3><strong>10</strong></h3>
              <span className="subtitle_sm">My Requests</span>
            </div>
          </div>
          <div className="col">
            <div className="cardNew p-4">
              <h3 className="text-warning">04</h3>
              <span className="subtitle_sm">Pendings</span>
            </div>
          </div>
          <div className="col">
            <div className="cardNew p-4">
              <h3 className="text-success">02</h3>
              <span className="subtitle_sm">Approved</span>
            </div>
          </div>
          <div className="col">
            <div className="cardNew p-4">
              <h3 className="text-danger">11</h3>
              <span className="subtitle_sm">Rejected</span>
            </div>
          </div>
        </div>

        <div className="row">
          {/* Data Table */}
          <div className="col-12">
            <div className="card_tb">
              {loading ? (
                <div>Loading...</div>
              ) : adhocData.length > 0 ? (
                <DataTable
                  value={adhocData}
                  paginator
                  rows={10}
                  rowsPerPageOptions={[5, 10, 25, 50]}
                  loading={loading}
                >
                  <Column sortable field="adhocid" header="Adhoc ID"></Column>
                  <Column field="empCode" header="EmployeeID"></Column>
                  <Column field="empName" header="Employee Name"></Column>
                  <Column field="AdhocDate" header="Shift Date"></Column>
                  <Column field="ShiftTime" header="Shift"></Column>
                  <Column field="TripType" header="Trip Type"></Column>
                  <Column field="facilityName" header="Facility"></Column>
                  <Column field="Status" header="Status"></Column>
                  <Column field="RaisedBy" header="Raised By"></Column>
                  <Column field="adhocreason" header="Reason"></Column>
                  <Column field="AprovedBy" header="Approved"></Column>
                  <Column field="" header="Action" body={deleteBtn}></Column>
                </DataTable>
              ) : (
                <div>No data available</div>
              )}
            </div>
          </div>

          {/* Sidebar Form */}
          <PrimeSidebar
            visible={visibleLeft}
            position="right"
            onHide={() => setVisibleLeft(false)}
            style={{ width: "80%" }}
            showCloseIcon={false}
            dismissable={false}
          >
            <div className="sidebarHeader d-flex justify-content-between align-items-center sidebarTitle p-0">
              <h6 className="sidebarTitle">Raise Adhoc</h6>
              <Button
                icon="pi pi-times"
                className="p-button-rounded p-button-text"
                onClick={() => setVisibleLeft(false)}
              />
            </div>
            <div className="sidebarBody p-3">
              <div className="row">
                <div className="col-12">
                  <div className="row">
                    <div className="field col-2 mb-3">
                      <SelectButton
                        severity="success"
                        value={value}
                        onChange={(e) => setValue(e.value)}
                        options={options}
                        className="no-label"
                        style={{ width: "100%" }}
                      />
                    </div>
                    <div className="field col-2 mb-3">
                      <label>Select Date</label>
                      <InputText
                        type="date"
                        className="form-control"
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                      />
                    </div>
                    <div className="field col-2 mb-3">
                      <label>Facility</label>
                      <Dropdown
                        value={selectedFacility}
                        options={facilityData}
                        optionLabel="facilityName"
                        optionValue="Id"
                        placeholder="Select Facility"
                        className="w-100"
                        filter
                        onChange={(e) => {
                          console.log("Selected Facility:", e.value);
                          setSelectedFacility(e.value);
                        }}
                        disabled={loading}
                      />
                    </div>
                    <div className="field col-2 mb-3">
                      <label>Shift</label>
                      <Dropdown
                        value={selectedShift}
                        options={shiftData}
                        optionLabel="ShiftName"
                        optionValue="ShiftId"
                        placeholder="Select Shift"
                        className="w-100"
                        filter
                        onChange={(e) => {
                          console.log("Selected Shift:", e.value);
                          setSelectedShift(e.value);
                        }}
                        disabled={!selectedFacility || loading}
                      />
                    </div>
                    <div className="field col-2 mb-3">
                      <label>Request Type</label>
                      <Dropdown
                        value={selectedRequestType}
                        options={requestTypes}
                        optionLabel="name"
                        optionValue="value"
                        placeholder="Select Request Type"
                        className="w-100"
                        filter
                        onChange={handleRequestTypeChange}
                      />
                    </div>

                    <div className="field col-2 mb-3">
                      <label>Reason</label>
                      <Dropdown
                        optionLabel="name"
                        placeholder="Select Reason"
                        className="w-100"
                        filter
                      />
                    </div>
                    <hr className="mx-3" />
                    <div className="field col-2">
                      <label>Select Manager</label>
                      <Dropdown
                        value={selectedManager}
                        options={managerData}
                        optionLabel="ManagerName"
                        optionValue="MgrId"
                        placeholder="Select Manager"
                        className="w-100"
                        filter
                        onChange={(e) => {
                          console.log("Selected Manager:", e.value);
                          setSelectedManager(e.value);
                        }}
                      />
                    </div>
                    <div className="col-12">
                      <div className="card_tb">
                        <DataTable value="" selectionMode="">
                          <Column
                            selectionMode="multiple"
                            headerStyle={{ width: "3rem" }}
                          ></Column>
                          <Column field="code" header="Employee"></Column>
                          <Column field="name" header="Project"></Column>
                          <Column field="category" header="Facility"></Column>
                        </DataTable>
                      </div>
                    </div>
                    {/* Fixed button container at bottom of sidebar */}
                    <div className="sidebar-fixed-bottom">
                      <div className="d-flex gap-3 justify-content-end">
                        <Button
                          label="Cancel"
                          className="btn btn-outline-secondary"
                          onClick={() => setVisibleLeft(false)}
                        />
                        <Button
                          label="Save Changes"
                          className="btn btn-success me-3" onClick={handleSave}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </PrimeSidebar>
        </div>
      </div>
    </>
  );
};

export default AdhocManagement;

const fetchEmployeeData = async () => {
    try {
      setLoading(true);
      const empidname = "-1";
      const locationid = sessionStorage.getItem("locationId");
      const managerID = sessionStorage.getItem("ID");
      
      const params = {
        empidname: empidname,
        locationid: locationid,
        managerID: managerID,
      };

      console.log("Fetching employee data with params:", params);
      const response = await AdhocmanagementService.EmpSearchManager(params);
      
      // Handle the response properly
      let employeeList = [];
      if (typeof response === 'string') {
        try {
          employeeList = JSON.parse(response);
        } catch (e) {
          console.error('Error parsing response:', e);
        }
      } else if (Array.isArray(response)) {
        employeeList = response;
      } else if (response && typeof response === 'object') {
        employeeList = [response];
      }

      console.log("Employee data retrieved:", employeeList);
      setEmployeeData(employeeList);
    } catch (error) {
      console.error("Error fetching employee data:", error);
      setEmployeeData([]);
    } finally {
      setLoading(false);
    }
  };
