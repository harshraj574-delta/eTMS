import { api } from "../axios/api";
class ManageRouteService {
  async SelectBaseFacility(params) {
    try {
      const response = await api.post("/SelectBaseFacility", {
        userid: params.userid,
      });
      return response.data; // Return the actual data from the response
     // console.log("SelectBaseFacility response:", response.data); // Log the response data
    } catch (error) {
      console.error("Error in SelectBaseFacility:", error);
      throw error;
    }
  }
  async GetShiftByFacilityType(params) {
    try {
      const response = await api.post("/GetShiftByFacilityType", {
        facid: params.facid,
        type: params.type,
      });
     // console.log("GetShiftByFacilityType response:", response.data); // Log the response data
      return response.data; // Return the actual data from the response
    } catch (error) {
      console.error("Error in GetShiftByFacilityType:", error);
      throw error;
    }
  }
  async GetRoutesByOrder(params) {
    const response = await api.post("/GetRoutesByOrder", {
        sDate: params.sDate,
        eDate: params.eDate,
        FacilityID: params.FacilityID,
        TripType: params.TripType,
        Shifttimes: params.Shifttimes,
        OrderBy: params.OrderBy,
        Direction: params.Direction,
        Routeid: params.Routeid,
        occ_seater: params.occ_seater
      });
      //console.log("GetRoutesByOrder response:", response.data);
      return response.data;
    } catch (error) {
      console.error("Error in GetRoutesByOrder:", error);
      throw error;
    }
    async GetRoutesDetailsnew(params) {
        try {
          const response = await api.post("/GetRoutesDetailsnew", {
            RouteID: params.RouteID,
            isAdd: params.isAdd
          });
          console.log("GetRoutesDetailsnew response:", response.data);
          return response.data;
        } catch (error) {
          console.error("Error in GetRoutesDetailsnew:", error);
          throw error;
        }
      }
}
export default new ManageRouteService();
