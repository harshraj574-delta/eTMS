import React, { useState, useEffect, useCallback, useRef } from "react";
import Sidebar from "./Master/SidebarMenu";
import Header from "./Master/Header";
import { apiService } from "../services/api";

import { Calendar } from "primereact/calendar";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Dropdown } from 'primereact/dropdown';
import { Checkbox } from 'primereact/checkbox';
import { Badge } from "primereact/badge";
import { Button } from "primereact/button";
import { InputText } from "primereact/inputtext";
import { RadioButton } from 'primereact/radiobutton';
import { FilterMatchMode } from "primereact/api";
import { Sidebar as PrimeSidebar } from "primereact/sidebar";
import sessionManager from "../utils/SessionManager";

function ManageEmployee() {
    // State declarations
    const [employees, setEmployees] = useState([]);
    const [managers, setManagers] = useState([]);
    const [selectedEmployee, setSelectedEmployee] = useState(null);
    const [visibleLeft, setVisibleLeft] = useState(false);
    const [visibleLeftAdd, setVisibleLeftAdd] = useState(false);
    const [isEditable, setIsEditable] = useState(false); // Add this line to define the isEditable state
    const [filters, setFilters] = useState({
        global: { value: null, matchMode: FilterMatchMode.CONTAINS },
    });
    const [loading, setLoading] = useState(false);
    const [searchKeyword, setSearchKeyword] = useState('');
    const dt = useRef(null);
    const [processes, setProcesses] = useState([]);
    const [subProcesses, setSubProcesses] = useState([]);
    const [locations, setLocations] = useState([]);
    const [facilitys, setFacilitys] = useState([]);
    const [allFacilitys, setAllFacilitys] = useState([]);
    const [NewEmployee, setNewEmployee] = useState(ture);

    // Initial data loading
    useEffect(() => {
        getEmployeeData();
        getManagersList();
        GetProcessByFacility();
    }, []);

    // Get ProcessBy Facility
    const GetProcessByFacility = async () => {
        try {
            setLoading(true);
            const facilityid = sessionManager.getUserSession().FacilityID;
            const response = await apiService.GetProcessByFacility({
                facilityid: facilityid.toString()
            });

            if (Array.isArray(response)) {
                const formattedProcesses = response.map(process => ({
                    label: process.ProcessName || process.processName,
                    value: process.Id
                }));
                setProcesses(formattedProcesses);
            } else {
                setProcesses([]);
            }
        } catch (error) {
            console.error("Error fetching process data:", error);
            setProcesses([]);
        } finally {
            setLoading(false);
        }
    };

    // Get Sub Process
    const GetSubProcess = async (processId) => {
        try {
            setLoading(true);
            const response = await apiService.GetSubProcess({
                processid: processId,
            });

            if (Array.isArray(response)) {
                const formattedSubProcesses = response.map(subprocess => ({
                    label: subprocess.subProcessName,
                    value: subprocess.Id
                }));
                setSubProcesses(formattedSubProcesses);
            } else {
                setSubProcesses([]);
            }
        } catch (error) {
            console.error("Error fetching subprocess data:", error);
            setSubProcesses([]);
        } finally {
            setLoading(false);
        }
    };

    // Get Geo City By RS
    const locationid = async (id) => {
        try {
            setLoading(true);
            const response = await apiService.locationid({
                locationid: id
            });

            if (Array.isArray(response)) {
                const formattedCities = response.map(locations => ({
                    label: locations.City,
                    value: locations.City
                }));
                setLocations(formattedCities);
            } else {
                setLocations([]);
            }
        } catch (error) {
            console.error("Error fetching location data:", error);
            setLocations([]);
        } finally {
            setLoading(false);
        }
    };

    // selectFacility
    const selectFacility = async (id) => {
        try {
            setLoading(true);
            const response = await apiService.selectFacility({
                Userid: id
            });

            if (Array.isArray(response)) {
                const formattedFacility = response.map(facility => ({
                    label: facility.facilityName,
                    value: facility.Id
                }));
                setFacilitys(formattedFacility);
            } else {
                setFacilitys([]);
            }
        } catch (error) {
            console.error("Error fetching facility data:", error);
            setFacilitys([]);
        } finally {
            setLoading(false);
        }
    };

    // selectAllFacility
    const selectAllFacility = async (id) => {
        try {
            setLoading(true);
            const response = await apiService.selectAllFacility({
                Userid: id
            });

            if (Array.isArray(response)) {
                const formattedAllFacility = response.map(allFacility => ({
                    label: allFacility.facilityName,
                    value: allFacility.Id
                }));
                setAllFacilitys(formattedAllFacility);
            } else {
                setAllFacilitys([]);
            }
        } catch (error) {
            console.error("Error fetching facility data:", error);
            setAllFacilitys([]);
        } finally {
            setLoading(false);
        }
    };

    // Get managers list
    const getManagersList = async () => {
        try {
            setLoading(true);
            const response = await apiService.GetManagerList({
                locationid: "",
                empidname: "",
                IsAdmin: ""
            });

            if (Array.isArray(response)) {
                const formattedManagers = response.map(manager => ({
                    label: manager.empName || manager.EmpName || manager.userName || manager.UserName || manager.id,
                    value: manager.id || manager.Id || manager.empId || manager.EmpId
                }));
                setManagers(formattedManagers);
            } else {
                setManagers([]);
            }
        } catch (error) {
            console.error("Error fetching managers:", error);
            setManagers([]);
        } finally {
            setLoading(false);
        }
    };

    // Get Employee Data
    const getEmployeeData = async () => {
        try {
            setLoading(true);
            const facilityid = sessionManager.getUserSession().FacilityID;
            const response = await apiService.GetEmployeeList({
                facilityid: facilityid
            });
            
            if (Array.isArray(response)) {
                setEmployees(response);
            } else {
                console.error("Unexpected response format:", response);
                setEmployees([]);
            }
        } catch (error) {
            console.error("Error fetching employee data:", error);
            setEmployees([]);
        } finally {
            setLoading(false);
        }
    };

    // Handle search
    const handleEmpSearch = async () => {
        try {
            setLoading(true);
            const response = await apiService.EmpSearch({
                locationid: sessionManager.getUserSession().locationId,
                empidname: searchKeyword,
                IsAdmin: sessionManager.getUserSession().ISadmin,
            });

            if (Array.isArray(response)) {
                setEmployees(response);
            } else {
                setEmployees([]);
            }
        } catch (error) {
            console.error("Error searching employees:", error);
            setEmployees([]);
        } finally {
            setLoading(false);
        }
    };

    // Modify the openEditSidebar function (around line 170)
    const openEditSidebar = (employee) => {
        setSelectedEmployee(employee);
        setVisibleLeft(true);
        setIsEditable(false); // Reset edit mode when opening sidebar
    
        if (employee.processId) {
            GetSubProcess(employee.processId);
        }
        if (employee.id) {
            locationid(employee.id);
            
            if (sessionManager.getUserSession().ISadmin === 'Y') {
                selectAllFacility(employee.id);
            } else {
                selectFacility(employee.id);
            }
        }
    };

    // Handle input changes
    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setSelectedEmployee((prev) => ({ ...prev, [name]: value }));
    };

    // Status Badge
    const StatusData = (rowData) => (
        <Badge value={rowData.attrited === "N" ? "Active" : "Inactive"} 
               severity={rowData.attrited === "N" ? "badgee badge_success" : "badgee badge_danger"} />
    );

    // Excel export function
    const exportExcel = () => {
        if (dt && dt.current) {
            dt.current.exportCSV();
        }
    };

    const paginatorLeft = <Button type="button" icon="pi pi-refresh" text onClick={getEmployeeData} />;
    const paginatorRight = <Button type="button" icon="pi pi-download" text onClick={exportExcel} />;

    return (
        <>
            <Header pageTitle="Manage Employee" showNewButton={true} onNewButtonClick={() => {
                setNewEmployee({}); // Reset the form
                setVisibleLeftAdd(true); // Open the sidebar
            }} />
            <Sidebar />
            <div className="middle">
                <div className="row">
                    <div className="col-12">
                        <h6 className="pageTitle">Manage Employee</h6>
                        <div className="card_tb">
                            <div className="row mb-3">
                                <div className="col-3">
                                    <div className="p-inputgroup m-3 mb-0">
                                        <InputText
                                            placeholder="Keyword Search"
                                            value={searchKeyword}
                                            onChange={(e) => setSearchKeyword(e.target.value)}
                                            onKeyDown={(e) => e.key === 'Enter' && handleEmpSearch()}
                                            className="w-100"
                                        />
                                        <span className="p-inputgroup-addon" onClick={handleEmpSearch} style={{ cursor: "pointer" }}>
                                            <i className="pi pi-search"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>

                            <DataTable
                                ref={dt}
                                value={employees}
                                loading={loading}
                                paginator
                                rows={10}
                                rowsPerPageOptions={[5, 10, 25, 50]}
                                filters={filters}
                                stripedRows
                                currentPageReportTemplate="Showing {first} to {last} of {totalRecords} employees"
                                paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                                paginatorLeft={paginatorLeft}
                                paginatorRight={paginatorRight}
                                removableSort
                                emptyMessage="No employees found"
                            >
                                <Column sortable field="empCode" header="Employee Id" body={(rowData) => (
                                    <a href="#" onClick={(e) => {
                                        e.preventDefault();
                                        openEditSidebar(rowData);
                                    }}>
                                        {rowData.empCode}
                                    </a>
                                )}></Column>
                                <Column sortable field="empName" header="Employee Name"></Column>
                                <Column sortable field="ProcessName" header="Process"></Column>
                                <Column sortable field="facilityName" header="Facility Name"></Column>
                                <Column sortable field="email" header="E-mail Address"></Column>
                                <Column sortable field="tptReq" header="TptReq"></Column>
                                <Column sortable header="Status" body={StatusData}></Column>
                            </DataTable>
                        </div>
                    </div>
                </div>
            </div>

            {/* Edit Employee Sidebar */}
            <PrimeSidebar 
                visible={visibleLeft} 
                position="right" 
                onHide={() => setVisibleLeft(false)} 
                showCloseIcon={false} 
                dismissable={false} 
                style={{ width:'70%' }}
            >
                <div className="d-flex justify-content-between align-items-center sidebarTitle p-0">
                    <h6 className="sidebarTitle">{selectedEmployee?.empName || ''} - {selectedEmployee?.empCode || ''}</h6>
                    <div className="d-flex align-items-center gap-2">
                        <Button 
                            icon={isEditable ? "pi pi-lock-open" : "pi pi-lock"} 
                            className="btn btn-link d-flex" 
                            tooltip={isEditable ? "Disable" : "Enable"}
                            tooltipOptions={{ position: 'left' }}
                            onClick={() => setIsEditable(!isEditable)} 

                        />
                        <Button icon="pi pi-times" className="p-button-rounded p-button-text" onClick={() => setVisibleLeft(false)} />
                    </div>
                </div>
                {selectedEmployee && (
                    <div className="sidebarBody">
                        <div className="row">
                            <div className="col-12 mb-3">
                                <h6 className="sidebarSubTitle">Personal Details</h6>
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Employee Code</label>
                                <InputText className="form-control" name="empid" value={selectedEmployee.empCode || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Employee Name</label>
                                <InputText className="form-control" name="empName" value={selectedEmployee.empName || ""} onChange={handleInputChange}disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>User Name</label>
                                <InputText className="form-control" name="userName" value={selectedEmployee.userName || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>

                            <div className="field col-3 mb-3">
                                <label>Gender</label>
                                <div className="d-flex gap-3">
                                    <div className="d-flex align-items-center gap-2">
                                        <RadioButton
                                            inputId="genderMale"
                                            name="Gender"
                                            value="Male"
                                            onChange={handleInputChange}
                                            checked={selectedEmployee.Gender === "Male"} disabled={!isEditable}
                                        />
                                        <label htmlFor="ingredient1" className="ml-2">Male</label>
                                    </div>
                                    <div className="d-flex align-items-center gap-2">
                                        <RadioButton
                                            inputId="genderFemale"
                                            name="Gender"
                                            value="Female"
                                            onChange={handleInputChange}
                                            checked={selectedEmployee.Gender === "Female"} disabled={!isEditable}
                                        />
                                        <label htmlFor="ingredient2" className="ml-2">Female</label>
                                    </div>
                                </div>
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Mobile</label>
                                <InputText className="form-control" name="mobile" value={selectedEmployee.mobile || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Phone</label>
                                <InputText className="form-control" name="phone" value={selectedEmployee.phone || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-6 mb-3">
                                <label>Email</label>
                                <InputText className="form-control" name="email" value={selectedEmployee.email || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            
                            {/* Official Details Section */}
                            <div className="col-12 my-3">
                                <h6 className="sidebarSubTitle">Official Details</h6>
                            </div>
                            <div className="field col-3 mb-3">
                                <label className="d-block">Facility</label>
                                <Dropdown
                                    name="facilities"
                                    value={selectedEmployee.id || ""}
                                    onChange={handleInputChange}
                                    options={facilitys}
                                    placeholder="Select Facility"
                                    className="w-full md:w-14rem w-100"
                                    emptyMessage="No Facility available"
                                    filter
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label className="d-block">Process</label>
                                <Dropdown
                                    name="ProcessName"
                                    value={selectedEmployee.processId || ""}
                                    onChange={handleInputChange}
                                    options={processes}
                                    placeholder="Select a Process"
                                    className="w-full md:w-14rem w-100"
                                    emptyMessage="No Process available"
                                    filter
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Sub Process</label>
                                <Dropdown
                                    name="subProcessName"
                                    value={selectedEmployee.subProcessId || ""}
                                    onChange={handleInputChange}
                                    options={subProcesses}
                                    placeholder="Select a Sub Process"
                                    className="w-full md:w-14rem w-100"
                                    emptyMessage="No Sub Process available"
                                    filter
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label className="d-block">Manager</label>
                                <Dropdown
                                    name="managerId"
                                    value={selectedEmployee.managerId || ""}
                                    onChange={handleInputChange}
                                    options={managers}
                                    filter
                                    placeholder="Select a Manager"
                                    className="w-full md:w-14rem w-100"
                                    emptyMessage="No managers available"
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label className="d-block">Medical Case</label>
                                <Dropdown
                                    name="MedicalCase"
                                    value={selectedEmployee.MedicalCase || ""}
                                    onChange={handleInputChange}
                                    className="w-full md:w-14rem w-100"
                                    placeholder="Select Medical Case"
                                    options={[
                                        { label: 'No', value: '0' },
                                        { label: 'Family Way', value: '1' },
                                        { label: 'Special Category', value: '2' },
                                    ]}
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Medical Expiry Date</label>
                                <Calendar
                                    name="MedicalExpiryDate"
                                    value={selectedEmployee.MedicalExpiryDate ? new Date(selectedEmployee.MedicalExpiryDate) : null}
                                    onChange={(e) => handleInputChange({
                                        target: {
                                            name: "MedicalExpiryDate",
                                            value: e.value
                                        }
                                    })}
                                    className="w-100"
                                    dateFormat="dd/mm/yy"
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Project Code</label>
                                <InputText className="form-control" name="MedicalCaseDetails" value={selectedEmployee.ProcessName || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Emergency Contact No</label>
                                <InputText className="form-control" name="EmergencyContact" value={selectedEmployee.EmergencyContact || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Emergency Name</label>
                                <InputText className="form-control" name="EmergencyName" value={selectedEmployee.EmergencyName || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label className="d-block">Transport Required</label>
                                <Checkbox 
                                    checked={selectedEmployee.tptReq === "Y"}
                                    onChange={(e) => handleInputChange({
                                        target: {
                                            name: "tptReq",
                                            value: e.target.checked ? "Y" : "N"
                                        }
                                    })} 
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label className="d-block">Attrited</label>
                                <Checkbox checked={selectedEmployee.attrited === "Y"}
                                    onChange={(e) => handleInputChange({
                                        target: {
                                            name: "attrited",
                                            value: e.target.checked ? "Y" : "N"
                                        }
                                    })} disabled={!isEditable} />
                            </div>
                            
                            {/* Address Details Section */}
                            <div className="col-12 my-3">
                                <h6 className="sidebarSubTitle">Edit Address Details</h6>
                            </div>
                            <div className="field col-12 mb-3">
                                <label>Address</label>
                                <InputText className="form-control" name="address" value={selectedEmployee.address || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Pincode</label>
                                <InputText className="form-control" name="pincode" value={selectedEmployee.pincode || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>City</label>
                                <Dropdown
                                    name="City"
                                    value={selectedEmployee.City || ""}
                                    onChange={handleInputChange}
                                    options={locations}
                                    placeholder="Select City"
                                    className="w-full md:w-14rem w-100"
                                    emptyMessage="No cities available"
                                    filter
                                    disabled={!isEditable}
                                />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Area</label>
                                <InputText className="form-control" name="Colony" value={selectedEmployee.Colony || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Landmark</label>
                                <InputText className="form-control" name="Landmark" value={selectedEmployee.Landmark || ""} onChange={handleInputChange} disabled={!isEditable} />
                            </div>

                            <div className="d-flex gap-3 justify-content-end">
                                <Button label="Cancel" className="btn btn-outline-secondary" onClick={() => setVisibleLeft(false)} />
                                <Button 
                                    label="Update Changes" 
                                    className="btn btn-success" 
                                    onClick={() => setVisibleLeft(false)} 
                                    disabled={!isEditable}
                                />
                            </div>
                        </div>
                    </div>
                )}
            </PrimeSidebar>

            {/* Add Employee Sidebar */}
            <PrimeSidebar 
                visible={visibleLeftAdd} 
                position="right" 
                onHide={() => setVisibleLeftAdd(false)} 
                showCloseIcon={false} 
                dismissable={false} 
                style={{ width:'70%' }}
            >
                <div className="d-flex justify-content-between align-items-center sidebarTitle p-0">
                    <h6 className="sidebarTitle">Add Employee</h6>
                    <div className="d-flex align-items-center gap-2">
                        <Button icon="pi pi-times" className="p-button-rounded p-button-text" onClick={() => setVisibleLeftAdd(false)} />
                    </div>
                </div>
                <div className="sidebarBody">
                        <div className="row">
                            <div className="col-12 mb-3">
                                <h6 className="sidebarSubTitle">Personal Details</h6>
                            </div>
                            <div className="field col-3 mb-3">
                                <label>Employee Code</label>
                                <InputText 
                                    className="form-control" 
                                    name="empid" 
                                    value={selectedEmployee?.empid || ""}
                                    onChange={handleInputChange}
                                />
                            </div>
                            
                            </div>
                            
                </div>
                <div className="d-flex gap-3 justify-content-end">
                                <Button label="Cancel" className="btn btn-outline-secondary" onClick={() => setVisibleLeftAdd(false)} />
                                <Button 
                                    label="Add Employee" 
                                    className="btn btn-success" 
                                    onClick={() => setVisibleLeftAdd(false)}
                                />
                            </div>

            </PrimeSidebar>
        </>
    );
}

export default ManageEmployee;
