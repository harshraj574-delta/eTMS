import { api } from "../axios/api";

class AdhocmanagementService {
    async SelectEmpAdhocRequest(params) {
        try {
            const response = await api.post("/SelectEmpAdhocRequest", params);
            return response.data; // Return the actual data from the response
        } catch (error) {
            console.error('Error in SelectEmpAdhocRequest:', error);
            throw error;
        }
    }
    async EmpSearchManager(params) {
        try {
            const response = await api.post("/EmpSearchManager", params);
            console.log("EmpSearchManager response:", response.data); // Log the response data
            let data = response.data;
            if (typeof data === 'string') {
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    console.error('Error parsing response:', e);
                }
            }
            return data; // Return the actual data from the response
        } catch (error) {
            console.error('Error in EmpSearchManager:', error);
            throw error;
        }
    }
    async GetBackupMgrId(params) {
        try {
            const response = await api.post("/GetBackupMgrId", params);
            console.log("GetBackupMgrId response:", response.data);

            // Parse the response if it's a string
            let data = response.data;
            if (typeof data === 'string') {
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    console.error('Error parsing response:', e);
                }
            }

            return data;
        } catch (error) {
            console.error('Error in GetBackupMgrId:', error);
            throw error;
        }
    }
    async SelectFacilityByGroup (params){
        try {
            const response = await api.post("/SelectFacilityByGroup", params);
            console.log("SelectFacilityByGroup response:", response.data); // Log the response data
            let data = response.data;
            if (typeof data === 'string') {
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    console.error('Error parsing response:', e);
                }
            }
            return data; // Return the actual data from the response
        }   catch (error) {
            console.error('Error in SelectFacilityByGroup:', error);
            throw error;
        }
    }
    async DeleteAdhoc(params) {
        try {
            const response = await api.post("/DeleteAdhoc", params);
            console.log("DeleteAdhoc response:", response.data); // Log the response data
            return response.data; // Return the actual data from the response
        } catch (error) {
            console.error('Error in DeleteAdhoc:', error);
            throw error;
        }
    }

    //get pick shift Adhoc
    async getpickshiftAdhoc(params) {
        try {
            console.log("Calling getpickshiftAdhoc with params:", params);            
            const response = await api.post("/getpickshiftAdhoc", params);
            
            let data = response.data;    
            // Attempt to parse string responses
            if (typeof data === 'string') {
                try {
                    data = JSON.parse(data);
                } catch (e) {
                    console.error("Failed to parse string response:", e);
                    return data; // Return raw string if parsing fails
                }
            }    
            return data;
        } catch (error) {
            console.error("Error in getpickshiftAdhoc:", error.response?.data || error.message);
            return []; // Return fallback empty array on error
        }
    }
    


    async getdropshiftadhoc(params) {       
        try {
            const response = await api.post("/getdropshiftadhoc", params);
            console.log("getdropshiftadhoc raw response:", response);
            console.log("getdropshiftadhoc data:", response.data);// Log the response data
            return response.data; // Return the actual data from the response
        } catch (error) {
            console.error('Error in getdropshiftadhoc:', error);
            throw error;
        }
    }
}
export default new AdhocmanagementService;