import React, { useEffect, useState, useRef } from "react";
import { MapContainer, TileLayer, Polyline, Marker, Popup, LayerGroup, useMap } from "react-leaflet";
import L from "leaflet";
import polyline from "@mapbox/polyline";
import "leaflet/dist/leaflet.css";
import ManageRouteService from "../services/compliance/ManageRouteService";

// Helper function for retrying failed requests with an async function
const retryAsync = async (asyncFn, args, maxRetries = 3, delay = 1000) => {
  let lastError;
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await asyncFn(args);
    } catch (error) {
      lastError = error;
      console.error(`Request failed (attempt ${i + 1}/${maxRetries}):`, error);
      if (i < maxRetries - 1) {
        console.log(`Retrying in ${delay}ms (attempt ${i + 2}/${maxRetries})...`);
        await new Promise(resolve => setTimeout(resolve, delay * (i + 1))); // Exponential backoff
      }
    }
  }
  throw lastError;
};

// Helper function to parse URL query parameters
const getQueryParams = () => {
  const search = window.location.search.substring(1);
  const params = {};
  
  search.split('&').forEach(param => {
    const [key, value] = param.split('=');
    if (key && value !== undefined) {
      params[key] = decodeURIComponent(value);
    }
  });
  
  return params;
};

// Helper for colored SVG marker
function createColoredMarker(color, label) {
  const svg = `
    <svg width="28" height="28" viewBox="0 0 28 28" 
         xmlns="http://www.w3.org/2000/svg">
      <circle cx="14" cy="14" r="12" fill="${color}" stroke="#fff" stroke-width="1.5"/>
      <text x="14" y="19" text-anchor="middle" font-size="13" font-family="Inter,Arial,sans-serif" 
            fill="#fff" font-weight="bold">${label || ""}</text>
    </svg>
  `;
  return new L.Icon({
    iconUrl: "data:image/svg+xml;base64," + btoa(svg),
    iconSize: [28, 28],
    iconAnchor: [14, 28],
    popupAnchor: [0, -28],
  });
}

const colors = [
  "#4285F4", // Google Blue
  "#EA4335", // Google Red
  "#FBBC05", // Google Yellow
  "#34A853", // Google Green
  "#A142F4", // Purple
  "#F44292", // Pink
  "#00B8D9", // Cyan
  "#FF6D01", // Orange
  "#46BDC6", // Teal
  "#FFB300", // Amber
  "#8E24AA", // Deep Purple
  "#43A047", // Dark Green
  "#F4511E", // Deep Orange
  "#3949AB", // Indigo
  "#757575", // Grey
  "#C0CA33", // Lime
  "#D81B60", // Magenta
  "#00897B", // Turquoise
  "#6D4C41", // Brown
  "#7E57C2", // Lavender
];

// Helper to fit map to all route bounds
function FitMapToRoutes({ routes }) {
  const map = useMap();
  useEffect(() => {
    if (!routes.length) return;
    let bounds = [];
    routes.forEach(route => {
      if (route.geometry) {
        try {
          const coords = polyline.decode(route.geometry).map(coord => [coord[0], coord[1]]);
          bounds = bounds.concat(coords);
        } catch {}
      }
      if (route.stops) {
        bounds = bounds.concat(route.stops.map(stop => [parseFloat(stop.locationY), parseFloat(stop.locationX)]));
      }
    });
    if (bounds.length) {
      map.fitBounds(bounds, { padding: [40, 40] });
    }
  }, [routes, map]);
  return null;
}

export default function RouteMap() {
  const [routes, setRoutes] = useState([]);
  const [routeVisible, setRouteVisible] = useState({});
  const [showAll, setShowAll] = useState(true);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [queryParams, setQueryParams] = useState({});

  // Initialize query parameters from URL
  useEffect(() => {
    const params = getQueryParams();
    setQueryParams(params);
    console.log("Query parameters:", params);
  }, []);

  // Calculate total distance and average occupancy
  const totalDistance = routes.reduce((sum, route) => sum + (parseFloat(route.totaldist) || 0), 0);
  const totalEmployees = routes.reduce((sum, r) => sum + (r.stops ? r.stops.length : 0), 0);
  const avgOccupancy = routes.length > 0 ? (totalEmployees / routes.length).toFixed(1) : 0;

  // Fetch route data from APIs using ManageRouteService with retry mechanism
  useEffect(() => {
    // Only proceed if we have the required query parameters
    if (!queryParams.sDate || !queryParams.FacilityID || !queryParams.TripType) {
      console.log("Waiting for required query parameters...");
      return;
    }
    
    const fetchAllRouteData = async () => {
      setLoading(true);
      setError(null);
      try {
        // Build API parameters from URL query params with fallbacks for required fields
        const apiParams = {
          sDate: queryParams.sDate || '2025-05-14',
          eDate: queryParams.sDate || '2025-05-14', // Use same date for eDate
          FacilityID: queryParams.FacilityID || '1',
          TripType: queryParams.TripType || 'P',
          Shifttimes: queryParams.Shifttimes || '0900',
          OrderBy: 'Colony', // Keep OrderBy fixed
          Direction: queryParams.Direction || 'ASC',
          Routeid: queryParams.Routeid || '',
          occ_seater: -2 // Keep occ_seater fixed
        };
        
        console.log("API parameters:", apiParams);
        
        // 1. First fetch all routes using service with retry
        const routesResponse = await retryAsync(
          ManageRouteService.GetRoutesByOrder,
          apiParams
        );

        // Parse response data
        let routesData;
        try {
          routesData = typeof routesResponse === 'string' ? JSON.parse(routesResponse) : routesResponse;
          if (typeof routesData === 'string') {
            routesData = JSON.parse(routesData);
          }
          
          console.log("Routes data:", routesData);
          
          if (!routesData || !Array.isArray(routesData)) {
            throw new Error('Invalid response format: expected array of routes');
          }
        } catch (parseError) {
          console.error('Failed to parse routes response:', parseError);
          throw new Error('Invalid JSON response from routes API');
        }

        // 2. For each route, fetch details and geometry in parallel with retry
        const routesWithDetails = await Promise.all(
          routesData.map(async (route) => {
            try {
              // Use Promise.all to parallelize requests with retry for each
              const [details, geometry] = await Promise.all([
                retryAsync(
                  ManageRouteService.GetRoutesDetailsnew,
                  {
                    RouteID: route.RouteID,
                    isAdd: 0
                  }
                ),
                retryAsync(
                  ManageRouteService.Get_RouteGeometry,
                  {
                    RouteID: route.RouteID
                  }
                )
              ]);

              // Parse details data
              let detailsData;
              try {
                detailsData = typeof details === 'string' ? JSON.parse(details) : details;
                if (typeof detailsData === 'string') {
                  detailsData = JSON.parse(detailsData);
                }
                if (!detailsData || !Array.isArray(detailsData)) {
                  throw new Error('Invalid details data structure');
                }
              } catch (parseError) {
                console.error('Failed to parse route details:', parseError);
                throw new Error('Invalid JSON response from details API');
              }

              // Parse geometry data
              let geometryData;
              try {
                let parsedGeometry = typeof geometry === 'string' ? JSON.parse(geometry) : geometry;
                if (typeof parsedGeometry === 'string') {
                  parsedGeometry = JSON.parse(parsedGeometry);
                }
                if (Array.isArray(parsedGeometry) && parsedGeometry.length > 0) {
                  parsedGeometry = parsedGeometry[0];
                }
                if (!parsedGeometry || !parsedGeometry.geometry) {
                  throw new Error('Invalid geometry data structure');
                }
                geometryData = parsedGeometry;
              } catch (parseError) {
                console.error('Failed to parse route geometry:', parseError);
                throw new Error('Invalid JSON response from geometry API');
              }

              // Transform employee details into stops format
              const stops = detailsData.map(emp => ({
                stopNo: emp.stopNo,
                address: emp.address,
                empCode: emp.empCode,
                eta: emp.ETA,
                locationX: emp.GeoX,
                locationY: emp.GeoY
              }));

              return {
                routeid: route.RouteID,
                geometry: geometryData.geometry,
                stops,
                totaldist: route.totaldist,
                facility: {
                  facilityGeoX: detailsData[0]?.facGeoX,
                  facilityGeoY: detailsData[0]?.facGeoY
                }
              };
            } catch (error) {
              console.error(`Error fetching details for route ${route.RouteID}:`, error);
              return null;
            }
          })
        );

        // Filter out failed routes
        const validRoutes = routesWithDetails.filter(route => route !== null);
        setRoutes(validRoutes);
        
        // Set all routes visible by default
        const vis = {};
        validRoutes.forEach((r) => (vis[r.routeid] = true));
        setRouteVisible(vis);
        setShowAll(true);
      } catch (error) {
        console.error('Error fetching route data:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    };

    fetchAllRouteData();
  }, [queryParams]); // Depend on queryParams

  // Toggle all routes
  const handleToggleAll = (checked) => {
    setShowAll(checked);
    const vis = {};
    routes.forEach((r) => (vis[r.routeid] = checked));
    setRouteVisible(vis);
  };

  // Toggle individual route
  const handleToggleRoute = (routeid) => {
    setRouteVisible((prev) => {
      const updated = { ...prev, [routeid]: !prev[routeid] };
      setShowAll(Object.values(updated).every(Boolean));
      return updated;
    });
  };

  // Loading animation component
  const LoadingScreen = () => (
    <div style={{
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: "rgba(255, 255, 255, 0.95)",
      backdropFilter: "blur(8px)",
      zIndex: 9999,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: "24px"
    }}>
      <div style={{
        width: "80px",
        height: "80px",
        position: "relative"
      }}>
        {/* Outer ring */}
        <div style={{
          position: "absolute",
          width: "100%",
          height: "100%",
          border: "4px solid #e2e8f0",
          borderTopColor: "#3b82f6",
          borderRadius: "50%",
          animation: "spin 1s linear infinite"
        }} />
        {/* Inner ring */}
        <div style={{
          position: "absolute",
          width: "60%",
          height: "60%",
          top: "20%",
          left: "20%",
          border: "4px solid #e2e8f0",
          borderTopColor: "#3b82f6",
          borderRadius: "50%",
          animation: "spin 0.8s linear infinite reverse"
        }} />
      </div>
      <div style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: "8px"
      }}>
        <h2 style={{
          fontSize: "24px",
          fontWeight: "600",
          color: "#1e293b",
          margin: 0
        }}>
          Loading Routes
        </h2>
        <p style={{
          fontSize: "16px",
          color: "#64748b",
          margin: 0
        }}>
          Please wait while we fetch your route data...
        </p>
      </div>
      <style>
        {`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}
      </style>
    </div>
  );

  // Error message component
  const ErrorMessage = ({ message }) => (
    <div style={{
      position: "fixed",
      top: "24px",
      right: "24px",
      zIndex: 1000,
      background: "white",
      padding: "16px 20px",
      borderRadius: "12px",
      boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
      maxWidth: "400px",
      borderLeft: "4px solid #ef4444",
      animation: "slideIn 0.3s ease-out"
    }}>
      <div style={{
        display: "flex",
        alignItems: "center",
        gap: "12px"
      }}>
        <div style={{
          width: "24px",
          height: "24px",
          borderRadius: "50%",
          background: "#fee2e2",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          color: "#ef4444",
          fontWeight: "600"
        }}>
          !
        </div>
        <div>
          <h3 style={{
            margin: "0 0 4px 0",
            fontSize: "16px",
            fontWeight: "600",
            color: "#1e293b"
          }}>
            Error Loading Routes
          </h3>
          <p style={{
            margin: 0,
            fontSize: "14px",
            color: "#64748b"
          }}>
            {message}
          </p>
        </div>
      </div>
      <style>
        {`
          @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
          }
        `}
      </style>
    </div>
  );

  // Add the style block for sidebar and route card styling
  const sidebarStyles = `
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
    .sidebar-react {
      position: absolute;
      top: 10px;
      left: 10px;
      z-index: 1000;
      background: white;
      padding: 12px;
      border-radius: 6px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      max-height: calc(100vh - 40px);
      overflow-y: auto;
      width: 300px;
      font-family: 'Inter', sans-serif;
    }
    .summary-stats {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 8px;
      margin-bottom: 15px;
    }
    .stat-item {
      background: #f8fafc;
      border-radius: 6px;
      padding: 6px;
      transition: all 0.2s ease;
    }
    .stat-item:nth-child(1) { background: #dbeafe; }
    .stat-item:nth-child(2) { background: #dcfce7; }
    .stat-item:nth-child(3) { background: #fef9c3; }
    .stat-item:nth-child(4) { background: #fee2e2; }
    .stat-label {
      color: #475569;
      font-size: 8px;
      font-weight: 600;
      text-transform: uppercase;
      margin-bottom: 2px;
    }
    .stat-value {
      color: #1e293b;
      font-size: 14px;
      font-weight: 600;
    }
    .sidebar-switch-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 18px;
      padding: 0 2px;
    }
    .switch-label {
      font-weight: 600;
      color: #1e293b;
      font-size: 15px;
      user-select: none;
    }
    .route-item {
      font-size: 14px;
      padding: 0px;
      margin:0 0 6px 0;
      height: auto;
      width: 100%;
      cursor: pointer;
    }
    .route-summary {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 6px;
      padding: 6px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      margin-bottom: 0px;
      transition: all 0.3s ease;
      color: #1e293b;
      font-size: 12px;
      line-height: 1.2;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .route-summary:hover {
      background: #f3f4f6;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
    }
    .route-summary.active {
      background-color: #3b82f6;
      color: white;
      border-color: #3b82f6;
    }
    .route-summary .route-name {
      font-size: 14px;
      font-weight: 600;
      color: #111827;
      margin-bottom: 12px;
    }
    .route-summary.active .route-name { color: #fff; }
    .route-summary .route-stats {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 6px;
      font-size: 14px;
      color: #475569;
    }
    .route-summary .route-stats .stat-item {
      background: #f9fafb;
      border-radius: 6px;
      padding: 6px;
      transition: all 0.3s ease;
    }
    .route-summary .route-stats .stat-item:hover {
      background: #f3f4f6;
    }
    .route-summary .route-stats .stat-label {
      font-weight: 600;
      text-transform: uppercase;
      font-size: 8px;
      color: #6b7280;
    }
    .route-summary .route-stats .stat-value {
      font-weight: 700;
      color: #111827;
      transition: color 0.2s;
    }
    .route-summary.active .route-stats .stat-item {
      background: rgba(255,255,255,0.92);
    }
    .route-summary.active .route-stats .stat-label {
      color: #2563eb;
    }
    .route-summary.active .route-stats .stat-value {
      color: #2563eb;
    }
  `;

  return (
    <div style={{ height: "100vh", width: "100vw", fontFamily: "'Inter', sans-serif", background: "#f6f8fa" }}>
      <style>{sidebarStyles}</style>
      {loading && <LoadingScreen />}
      {error && <ErrorMessage message={error} />}
      {/* Sidebar */}
      <div className="sidebar-react">
        <div className="summary-stats">
          <div className="stat-item">
            <div className="stat-label">Routes</div>
            <div className="stat-value">{routes.length}</div>
          </div>
          <div className="stat-item">
            <div className="stat-label">Distance</div>
            <div className="stat-value">{totalDistance.toFixed(1)} km</div>
          </div>
          <div className="stat-item">
            <div className="stat-label">Employees</div>
            <div className="stat-value">{totalEmployees}</div>
          </div>
          <div className="stat-item">
            <div className="stat-label">Avg Occupancy</div>
            <div className="stat-value">{avgOccupancy}</div>
          </div>
        </div>
        <div className="sidebar-switch-row">
          <span className="switch-label">Show All Routes</span>
          <label className="switch" style={{ position: "relative", display: "inline-block", width: 44, height: 24 }}>
            <input
              type="checkbox"
              checked={showAll}
              onChange={(e) => handleToggleAll(e.target.checked)}
              style={{ opacity: 0, width: 0, height: 0 }}
            />
            <span className="slider" style={{
              position: "absolute",
              cursor: "pointer",
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              backgroundColor: showAll ? "#3b82f6" : "#e5e7eb",
              transition: ".3s",
              borderRadius: 24,
            }}>
              <span
                style={{
                  position: "absolute",
                  content: '""',
                  height: 18,
                  width: 18,
                  left: showAll ? 23 : 3,
                  bottom: 3,
                  backgroundColor: "#fff",
                  transition: ".3s",
                  borderRadius: "50%",
                  boxShadow: "0 1px 4px rgba(0,0,0,0.08)",
                  display: "block",
                }}
              />
            </span>
          </label>
        </div>
        <div id="route-buttons">
          {routes.map((route, idx) => (
            <div className="route-item" key={route.routeid}>
              <div
                className={`route-summary${routeVisible[route.routeid] ? " active" : ""}`}
                data-routeid={route.routeid}
                style={{
                  borderLeft: `6px solid ${colors[idx % colors.length]}`,
                  cursor: "pointer",
                }}
                onClick={() => handleToggleRoute(route.routeid)}
              >
                <div className="route-name">Route {route.routeid}</div>
                <div className="route-stats">
                  <div className="stat-item">
                    <div className="stat-label">Distance</div>
                    <div className="stat-value">{route.totaldist ? `${parseFloat(route.totaldist).toFixed(1)} km` : "—"}</div>
                  </div>
                  <div className="stat-item">
                    <div className="stat-label">Avg Occupancy</div>
                    <div className="stat-value">{route.stops ? (route.stops.length / 1).toFixed(1) : "—"}</div>
                  </div>
                  <div className="stat-item">
                    <div className="stat-label">Duration</div>
                    <div className="stat-value">{"—"}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Map */}
      <MapContainer
        center={[22.5937, 78.9629]}
        zoom={6}
        style={{ height: "100vh", width: "100vw", zIndex: 1 }}
      >
        <FitMapToRoutes routes={routes} />
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution="© OpenStreetMap"
        />
        {routes.map((route, idx) =>
          routeVisible[route.routeid] ? (
            <LayerGroup key={route.routeid}>
              {/* Polyline */}
              {route.geometry && route.geometry.length > 0 && (
                <Polyline
                  positions={polyline
                    .decode(route.geometry)
                    .map((coord) => [coord[0], coord[1]])}
                  color={colors[idx % colors.length]}
                  weight={5}
                  opacity={1}
                />
              )}
              {/* Stops */}
              {route.stops &&
                route.stops.map((stop, sidx) => (
                  <Marker
                    key={sidx}
                    position={[
                      parseFloat(stop.locationY),
                      parseFloat(stop.locationX),
                    ]}
                    icon={createColoredMarker(colors[idx % colors.length], stop.stopNo)}
                  >
                    <Popup>
                      <div style={{ minWidth: 220, maxWidth: 260 }}>
                        <div style={{ fontWeight: 600, color: "#3b82f6" }}>
                          Stop <span style={{ background: "#e0e7ff", color: "#3730a3", borderRadius: 6, padding: "2px 8px", fontSize: 13, marginLeft: 4 }}>{stop.stopNo}</span>
                        </div>
                        <div style={{ fontSize: 15, fontWeight: 500, color: "#111827", marginBottom: 10, marginTop: 2 }}>
                          {stop.address}
                        </div>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                          <span style={{ color: "#64748b", fontSize: 13, fontWeight: 500 }}>Emp Code:</span>
                          <span style={{ color: "#0ea5e9", fontSize: 13, fontWeight: 600, marginLeft: 8 }}>{stop.empCode || "-"}</span>
                        </div>
                        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 3 }}>
                          <span style={{ color: "#64748b", fontSize: 13, fontWeight: 500 }}>ETA:</span>
                          <span style={{ color: "#0ea5e9", fontSize: 13, fontWeight: 600, marginLeft: 8 }}>{stop.eta || "-"}</span>
                        </div>
                      </div>
                    </Popup>
                  </Marker>
                ))}
              {/* Facility */}
              {route.facility &&
                route.facility.facilityGeoY &&
                route.facility.facilityGeoX && (
                  <Marker
                    position={[
                      parseFloat(route.facility.facilityGeoY),
                      parseFloat(route.facility.facilityGeoX),
                    ]}
                    icon={
                      new L.Icon({
                        iconUrl: "public/images/facility-icon.png",
                        iconSize: [36, 36],
                        iconAnchor: [18, 36],
                        popupAnchor: [0, -36],
                      })
                    }
                  >
                    <Popup>
                      <b>Facility</b>
                    </Popup>
                  </Marker>
                )}
            </LayerGroup>
          ) : null
        )}
      </MapContainer>
    </div>
  );
}
