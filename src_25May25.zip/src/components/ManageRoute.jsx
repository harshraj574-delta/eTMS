import React, { useEffect, useState, useRef } from "react";
import Header from "./Master/Header";
import Sidebar from "./Master/SidebarMenu";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Button } from "primereact/button";
import { MultiSelect } from "primereact/multiselect";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Toast } from "primereact/toast";
import { Col } from "react-bootstrap";
import { Weight } from "lucide-react";
import { apiService } from "../services/api";
import ManageRouteService from "../services/compliance/ManageRouteService";

import { Sidebar as PrimeSidebar } from "primereact/sidebar"; // Renamed to avoid conflict with your Sidebar component

const ManageRoute = () => {
  const [expandedRows, setExpandedRows] = useState(null);
  const toast = useRef(null);
  const [facilities, setFacilities] = useState([]);
  const [selectedFacility, setSelectedFacility] = useState(null);
  const [selectedTripType, setSelectedTripType] = useState("P");
  const [shifts, setShifts] = useState([]);
  const [selectedShifts, setSelectedShifts] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [routeDetails, setRouteDetails] = useState({});
  const userID = sessionStorage.getItem("ID");
  const tripTypeOptions = [
    { label: "Pick", value: "P" },
    { label: "Drop", value: "D" },
  ];

  const [rowsPerPage] = useState(10); // Default 
  const [viewMap, setViewMap] = useState(false);

  useEffect(() => {
    fetchFacilities();
    fetchShifts(); // Fetch shifts when selectedFacility or selectedTripType changes
  }, [selectedFacility, selectedTripType]);
  const fetchFacilities = async () => {
    try {
      const response = await ManageRouteService.SelectBaseFacility({
        userid: userID,
      });
      //console.log("Facility Data Manage Route", response);

      // Parse response if it's a string
      const parsedResponse =
        typeof response === "string" ? JSON.parse(response) : response;

      // Ensure we have an array and map it correctly
      const formattedData = Array.isArray(parsedResponse)
        ? parsedResponse.map((item) => ({
            label: item.facility || item.facilityName, // Using facility or facilityName from your API response
            value: item.Id, // Using Id from your API response
          }))
        : [];

      // console.log("Formatted Data:", formattedData);
      setFacilities(formattedData);
    } catch (error) {
      console.error("Failed to fetch facilities:", error);
      toast.current.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to load facilities",
        life: 3000,
      });
    }
  };
  const fetchShifts = async () => {
    try {
      if (selectedFacility && selectedTripType) {
        const response = await ManageRouteService.GetShiftByFacilityType({
          facid: selectedFacility,
          type: selectedTripType,
        });
        //console.log("Shifts Response:", response);

        // Parse response if it's a string
        const parsedResponse =
          typeof response === "string" ? JSON.parse(response) : response;

        // Format the shift data according to the API structure
        const formattedShifts = Array.isArray(parsedResponse)
          ? parsedResponse.map((shift) => ({
              label: shift.shiftTime || shift.ShiftTime, // Handle both cases
              value: shift.shiftTime || shift.ShiftTime, // Using shiftTime as value too
            }))
          : [];

        //console.log("Formatted Shifts:", formattedShifts);
        setShifts(formattedShifts);
      }
    } catch (error) {
      console.error("Failed to fetch shifts:", error);
      toast.current.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to load shifts",
        life: 3000,
      });
    }
  };
  const handleSubmit = async () => {
    try {
      const response = await ManageRouteService.GetRoutesByOrder({
        sDate: shiftDate,
        eDate: shiftDate,
        FacilityID: selectedFacility,
        TripType: selectedTripType,
        Shifttimes: selectedShifts.join(","), // Convert array to comma-separated string
        OrderBy: "Routeno",
        Direction: "ASC",
        Routeid: "",
        occ_seater: -2,
      });

      console.log("Routes Data:", response);
      const parsedResponse =
        typeof response === "string" ? JSON.parse(response) : response;
      setTableData(parsedResponse || []); // You can set the table data here if needed
    } catch (error) {
      console.error("Failed to fetch routes:", error);
      toast.current.show({
        severity: "error",
        summary: "Error",
        detail: "Failed to load routes",
        life: 3000,
      });
    }
  };
  // Update the rowExpansionTemplate function
  const rowExpansionTemplate = (rowData) => {
    // Fetch details if not already loaded
    if (!routeDetails[rowData.RouteID]) {
      ManageRouteService.GetRoutesDetailsnew({
        RouteID: rowData.RouteID,
        isAdd: 0,
      })
        .then((response) => {
          const parsedResponse =
            typeof response === "string" ? JSON.parse(response) : response;
          setRouteDetails((prev) => ({
            ...prev,
            [rowData.RouteID]: parsedResponse,
          }));
        })
        .catch((error) => {
          console.error("Error fetching route details:", error);
          toast.current.show({
            severity: "error",
            summary: "Error",
            detail: "Failed to load route details",
            life: 3000,
          });
        });
    }

    return (
      <div className="bg-custom">
        <div className="p-0">
          <DataTable value={routeDetails[rowData.RouteID] || []}>
            <Column
              field="empCode"
              header="Employee"
              body={(rowData) => `${rowData.empCode} - ${rowData.empName}`}
            />
            <Column field="Gender" header="" />
            <Column field="address" header="Address" />
            {/* <Column field="Location" header="Location" /> */}
            {/* <Column field="landmark" header="Nodal Point" /> */}
            <Column field="Shift" header="Shift" />
            <Column field="tripType" header="" />
            <Column field="stopNo" header="Stop" />
            <Column field="ETA" header="ETA" />
          </DataTable>
        </div>
      </div>
    );
  };

  // const onRowExpand = (event) => {
  //   toast.current.show({
  //     severity: 'info',
  //     summary: 'Route Expanded',
  //     detail: `Route ${event.data.RouteID}`,
  //     life: 3000
  //   });
  // };

  // const onRowCollapse = (event) => {
  //   toast.current.show({
  //     severity: 'success',
  //     summary: 'Route Collapsed',
  //     detail: `Route ${event.data.RouteID}`,
  //     life: 3000
  //   });
  // };

  const expandAll = () => {
    let _expandedRows = {};

    // Use 'data' instead of 'products'
    data.forEach((p) => (_expandedRows[`${p.id}`] = true));

    setExpandedRows(_expandedRows);
  };

  const collapseAll = () => {
    setExpandedRows(null);
  };

  const allowExpansion = (rowData) => {
    return rowData.details && rowData.details.length > 0;
  };

  const rowExpansionTemplate1 = (rowData) => {
    return (
      <div className="bg-custom">
        <div className="p-0">
          {/* <h6 className="m-3 pageTitle">Details for Route {rowData.RouteID}</h6> */}
          <DataTable value={rowData.details}>
            <Column field="Employee" header="Employee" />
            <Column field="Address" header="Address" />
            {/* <Column field="Location" header="Location" /> */}
            <Column field="NodalPoint" header="Nodal Point" />
            <Column field="Shift" header="Shift" />
            <Column field="Stop" header="Stop" />
            <Column field="ETA" header="ETA" />
          </DataTable>
        </div>
      </div>
    );
  };

  // Add state for shift date
  const [shiftDate, setShiftDate] = useState(() => {
    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  });

  // const header = (
  //     <div className="flex flex-wrap justify-content-end gap-2">
  //         <Button icon="pi pi-plus" label="Expand All" onClick={expandAll} text />
  //         <Button icon="pi pi-minus" label="Collapse All" onClick={collapseAll} text />
  //     </div>
  // );

  return (
    <>
      <Header
        mainTitle="Transport"
        pageTitle="Manage Route"
        showNewButton={false}
      />
      <Sidebar />
      <div className="middle">
        <div className="row">
          <div className="col-12">
            <h6 className="pageTitle">Route Editing Window</h6>
          </div>
        </div>
        <div className="row">
          <div className="col-8">
            <div className="card_tb p-3">
              <div className="row">
                {/* <div className="col-2">
                  <label htmlFor="">Shift Date</label>
                  <InputText
                    type="date"
                    className="w-100"
                    placeholder="Trips for the Day"
                  />
                </div> */}
                <div className="col">
                  <label htmlFor="">Shift Date</label>
                  <InputText
                    type="date"
                    className="w-100"
                    placeholder="Trips for the Day"
                    value={shiftDate}
                    onChange={(e) => setShiftDate(e.target.value)}
                  />
                </div>
                <div className="col">
                  <label htmlFor="">Facility Name</label>
                  <Dropdown
                    id="facility"
                    placeholder="Select Facility"
                    className="w-100"
                    filter
                    value={selectedFacility}
                    onChange={(e) => setSelectedFacility(e.value)}
                    options={facilities}
                    optionLabel="label"
                    optionValue="value"
                  />
                </div>
                <div className="col">
                  <label htmlFor="tripType">Trip Type</label>
                  <Dropdown
                    id="tripType"
                    value={selectedTripType}
                    options={tripTypeOptions}
                    onChange={(e) => {
                      setSelectedTripType(e.value);
                      console.log("Selected Trip Type:", e.value);
                    }}
                    placeholder="Select Trip Type"
                    className="w-100"
                    filter
                  />
                </div>
                <div className="col">
                  <label htmlFor="shift">Shift</label>
                  <MultiSelect
                    id="shift"
                    value={selectedShifts}
                    options={shifts}
                    onChange={(e) => setSelectedShifts(e.value)}
                    optionLabel="label"
                    placeholder="Select Shifts"
                    maxSelectedLabels={3}
                    className="w-full md:w-20rem w-100"
                  />
                </div>
                <div className="col no-label">
                  <Button
                    className="btn btn-primary"
                    label="Submit"
                    onClick={handleSubmit}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="col-4">
            <div className="card_tb">
              <div class="cardNew1 w-100">
                <ul class="d-flex justify-content-between">
                  <li>
                    <h3>
                      <strong>3,543</strong>
                    </h3>
                    <span class="subtitle_sm text-danger">Employee</span>
                    {/* <span class="overline_text text-warning">Employee</span> */}
                  </li>
                  <li className="d-flex justify-content-between align-items-center">
                    <div>
                    <h3>
                      <strong>150</strong>
                    </h3>
                    <span class="subtitle_sm text-success">Routes</span>
                    </div>
                    <div>
                    <a href="#!" onClick={setViewMap}><span class="material-icons text-danger">room</span></a>
                    </div>
                    {/* <span class="overline_text text-success">100% reallocated</span> */}
                  </li>
                  <li>
                    <h3>
                      <strong>{150 / 2}</strong>
                    </h3>
                    <span class="subtitle_sm text-warning">Avg. Occupancy</span>
                    {/* <span class="overline_text text-warning">1245 Vehicles</span> */}
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="row">
          <div className="col-12">
            <div className="card_tb">
              <Toast ref={toast} />
              <DataTable
                value={tableData}
                expandedRows={expandedRows}
                onRowToggle={(e) => setExpandedRows(e.data)}
                rowExpansionTemplate={rowExpansionTemplate}
                dataKey="RouteID"
                onRowExpand={(e) =>
                  console.log("Expanded RouteID:", e.data.RouteID)
                }
                rows={rowsPerPage} 
                paginator
                emptyMessage="No Record Found"
              >
                <Column expander style={{ width: "3rem" }} />
                <Column
                  field="RouteID"
                  header="Route ID"
                  style={{ fontWeight: "bold" }}
                  body={(rowData) => (
                    <a href="#" style={{ fontWeight: "bold" }} onClick={setViewMap}>
                      {rowData.RouteID}
                    </a>
                  )}
                />
                <Column field="shiftTime" header="Shift" />
                <Column field="Address" header="Address" />
                {/* <Column field="ZONE" header="Zone" /> */}
                <Column field="totalStop" header="Stop" />
                <Column field="vendorname" header="Vendor" />
                {/* <Column field="stickerno2" header="Parking Slot" /> */}
                {/* <Column field="routeno" header="RouteNo" /> */}
              </DataTable>
            </div>
          </div>
        </div>
      </div>


      {/* Prime Sidebar Map */}
      <PrimeSidebar visible={viewMap} position="right" 
    showCloseIcon={false} 
    dismissable={false} 
    // fullScreen={true}
    style={{ width: "50%" }}
>
<div className="sidebarHeader d-flex justify-content-between align-items-center sidebarTitle p-0">
        <h6 className="sidebarTitle">Dummy Prime Sidebar</h6>
        <Button 
            icon="pi pi-times" 
            className="p-button-rounded p-button-text" 
            onClick={() => {setViewMap(false)}} 
        />
    </div>
    <div className="sidebarBody">
      Dummy
    </div>
    <div className="sidebar-fixed-bottom position-absolute pe-3">
        <div className="d-flex gap-3 justify-content-end">
            <Button label="Cancel" className="btn btn-outline-secondary"/>
            <Button label="Save" className="btn btn-success"/>
        </div>
    </div>
</PrimeSidebar>

    </>
  );
};

export default ManageRoute;
