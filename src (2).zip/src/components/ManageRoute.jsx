import React, { useEffect, useState, useRef } from "react";
import Header from "./Master/Header";
import Sidebar from "./Master/SidebarMenu";
import { InputText } from "primereact/inputtext";
import { Dropdown } from "primereact/dropdown";
import { Button } from "primereact/button";
import { MultiSelect } from "primereact/multiselect";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";
import { Toast } from 'primereact/toast';


const ManageRoute = () => {
  const [expandedRows, setExpandedRows] = useState(null);
  const toast = useRef(null);

  const onRowExpand = (event) => {
    toast.current.show({ 
      severity: 'info', 
      summary: 'Route Expanded', 
      detail: `Route ${event.data.RouteID}`, 
      life: 3000 
    });
  };

  const onRowCollapse = (event) => {
    toast.current.show({ 
      severity: 'success', 
      summary: 'Route Collapsed', 
      detail: `Route ${event.data.RouteID}`, 
      life: 3000 
    });
  };

const expandAll = () => {
    let _expandedRows = {};

    // Use 'data' instead of 'products'
    data.forEach((p) => (_expandedRows[`${p.id}`] = true));
    
    setExpandedRows(_expandedRows);
};

const collapseAll = () => {
    setExpandedRows(null);
};

  const data = [
    {
      id: "1", // Add unique id for each row
      RouteID: "R001",
      Shift: "Morning",
      Address: "123 Main St",
      NodalLocation: "Central Depot",
      Zone: "North",
      Stop: "Stop A",
      Vendor: "VendorX",
      Parking: "Lot 1",
      // Add a nested array for expansion
      details: [
        { id: "1-1", stopName: "Stop 1", arrivalTime: "08:00", departureTime: "08:05" },
        { id: "1-2", stopName: "Stop 2", arrivalTime: "08:15", departureTime: "08:20" }
      ]
    },
    {
      id: "2", // Add unique id for each row
      RouteID: "R002",
      Shift: "Evening",
      Address: "456 Elm St",
      NodalLocation: "East Hub",
      Zone: "East",
      Stop: "Stop B",
      Vendor: "VendorY",
      Parking: "Lot 2",
      // Add a nested array for expansion
      details: [
        { id: "2-1", stopName: "Stop A", arrivalTime: "17:00", departureTime: "17:05" },
        { id: "2-2", stopName: "Stop B", arrivalTime: "17:15", departureTime: "17:20" }
      ]
    },
    // Add more rows as needed
  ];

  const allowExpansion = (rowData) => {
    return rowData.details && rowData.details.length > 0;
  };

  const rowExpansionTemplate = (rowData) => {
    return (
      <div className="p-0">
        <h6 className="m-3 pageTitle">Details for Route {rowData.RouteID}</h6>
        <DataTable value={rowData.details}>
          <Column field="id" header="ID" />
          <Column field="stopName" header="Stop Name" />
          <Column field="arrivalTime" header="Arrival Time" />
          <Column field="departureTime" header="Departure Time" />
        </DataTable>
      </div>
    );
  };

// const header = (
//     <div className="flex flex-wrap justify-content-end gap-2">
//         <Button icon="pi pi-plus" label="Expand All" onClick={expandAll} text />
//         <Button icon="pi pi-minus" label="Collapse All" onClick={collapseAll} text />
//     </div>
// );

  return (
    <>
      <Header pageTitle="Manage Employee" showNewButton={true} />
      <Sidebar />
      <div className="middle">
        <div className="row">
          <div className="col-12">
            <h6 className="pageTitle">Route Editing Window</h6>
          </div>
        </div>
        <div className="row">
          <div className="col-12">
            <div className="card_tb p-3">
              <div className="row">
                <div className="col-2">
                  <label htmlFor="">Shift Date</label>
                  <InputText
                    type="date"
                    className="w-100"
                    placeholder="Trips for the Day"
                  />
                </div>
                <div className="col-2">
                  <label htmlFor="">Facility Name</label>
                  <Dropdown
                    placeholder="Select Vendor"
                    className="w-100"
                    filter
                  />
                </div>
                <div className="col-2">
                  <label htmlFor="">Trip Type</label>
                  <Dropdown
                    placeholder="Select Vendor"
                    className="w-100"
                    filter
                  />
                </div>
                <div className="col-2">
                  <label htmlFor="">Shift</label>
                  <MultiSelect
                    value=""
                    options=""
                    optionLabel="name"
                    placeholder="Select Cities"
                    maxSelectedLabels={3}
                    className="w-full md:w-20rem w-100"
                  />
                </div>
                <div className="col-2 no-label">
                  <Button className="btn btn-primary" label="Submit" />
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Table */}
        <div className="row">
          <div className="col-12">
            <div className="card_tb">
              
              <Toast ref={toast} />
            <DataTable 
              value={data} 
              expandedRows={expandedRows} 
              onRowToggle={(e) => setExpandedRows(e.data)}
              onRowExpand={onRowExpand} 
              onRowCollapse={onRowCollapse} 
              rowExpansionTemplate={rowExpansionTemplate}
              dataKey="id" 
              // header={header} 
            >
              <Column expander style={{ width: '3rem' }} />
              <Column field="RouteID" header="RouteID" />
              <Column field="Shift" header="Shift" />
              <Column field="Address" header="Address" />
              <Column field="NodalLocation" header="Nodal/Location" />
              <Column field="Zone" header="Zone" />
              <Column field="Stop" header="Stop" />
              <Column field="Vendor" header="Vendor" />
              <Column field="Parking" header="Parking" />
            </DataTable>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ManageRoute;
