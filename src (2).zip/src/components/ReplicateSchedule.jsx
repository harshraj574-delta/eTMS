import React from "react";
import SidebarMenu from "./Master/SidebarMenu";
import Header from "./Master/Header";
import { Dropdown } from 'primereact/dropdown';

function ReplicateSchedule() {
    return (
        <>
            <Header /> 
            <SidebarMenu />
            <div className="middle">
                <div className="row">
                <div className="col-12">
                        <h6 className="pageTitle">Replicate Schedule</h6>
                    </div>
                    <div className="col-12">
                    <div class="card_tb p-3">
        <div class="row mb-3">
          
          <div class="col-5">
            <div class="">
              <h6 class="fs-16 mb-3 fw-bold titleStrip">From Week</h6>
              <form class="row row-cols-lg-auto justify-content-start">
                <div class="col-auto no-label p-0">
                  <div class="btn btn-link">
                    <span class="material-icons">chevron_left</span>
                  </div>
                </div>
                <div class="col-12">
                  <label class="form-label">Start Date</label>
                  <h6>01 April 2025</h6>
                </div>
                <div class="col-12">
                  <label class="form-label">End Date</label>
                  <h6>07 April 2025</h6>
                </div>
                <div class="col-auto no-label p-0">
                  <div class="btn btn-link">
                    <span class="material-icons">chevron_right</span>
                  </div>
                </div>
              </form>
            </div>
          </div>
          
          <div class="col-5">
            <h6 class="fs-16 mb-3 fw-bold titleStrip">To Week</h6>
            <div class="">
              <form class="row row-cols-lg-auto justify-content-start">
                <div class="col-auto no-label p-0">
                  <div class="btn btn-link" aria-disabled="true">
                    <span class="material-icons">chevron_left</span>
                  </div>
                </div>
                <div class="col-12">
                  <label class="form-label">Start Date</label>
                  <h6>07 April 2025</h6>
                </div>
                <div class="col-12">
                  <label class="form-label">End Date</label>
                  <h6>013 April 2025</h6>
                </div>
                <div class="col-auto no-label p-0">
                  <div class="btn btn-link">
                    <span class="material-icons">chevron_right</span>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div class="col-auto d-flex align-items-end">
            <div class="">
              <button type="button" class="btn btn-primary"> <span class="material-icons">
                swap_horiz
                </span> Replicate Schedule</button>
            </div>
          </div>
        </div>
      </div>
                    </div>
                    <div className="col-12">
                        <div class="card_tb">
                            <div className="row">
                              <div className="col-2">
                                <Dropdown placeholder="Select Facility" className="w-100 m-3" filter />
                              </div>
                            </div>
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th></th>
                                        <th>Employee Name</th>
                                        <th>Mon 31-March</th>
                                        <th>Tue 1-April</th>
                                        <th>Wed 2-April</th>
                                        <th>Thu 3-April</th>
                                        <th>Fri 4-April</th>
                                        <th>Sat 5-April</th>
                                        <th>Sun 6-April</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                    <td><input type="checkbox" class="form-check-input" />
                                        <img src="src/assets/location_icon.png" alt="" class="mx-2" />
                                        <img src="src/assets/no_transport_icon.png" alt="" />
                                    </td>
                                        <td>TMP123-Jhankar Sharma</td>
                                        <td>GGN 1700 <br /> GGN 0630</td>
                                        <td>GGN 1700 <br /> GGN 0630</td>
                                        <td>GGN 1700 <br /> GGN 0630</td>
                                        <td>GGN 1700 <br /> GGN 0630</td>
                                        <td>GGN 1700 <br /> GGN 0630</td>
                                        <td>GGN 1700 <br /> GGN 0630</td>
                                        <td>GGN 1700 <br /> GGN 0630</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default ReplicateSchedule;